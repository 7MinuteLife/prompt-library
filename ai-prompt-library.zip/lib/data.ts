import type { Prompt, Category } from "./types"

export const categories: Category[] = [
  { id: "creative", name: "Creative Writing" },
  { id: "business", name: "Business" },
  { id: "technical", name: "Technical" },
  { id: "marketing", name: "Marketing" },
  { id: "education", name: "Education" },
  { id: "personal", name: "Personal" },
]

export const promptData: Prompt[] = [
  {
    id: "1",
    title: "Product Description Generator",
    content:
      "Create a compelling product description for [product name]. The product has the following features: [list features]. The target audience is [describe audience]. The tone should be [professional/casual/enthusiastic].",
    description: "Generate professional product descriptions for e-commerce listings or marketing materials.",
    category: "Marketing",
    tags: ["e-commerce", "copywriting", "product"],
    models: ["GPT-4", "Claude 3", "GPT-3.5 Turbo"],
    createdAt: "2023-11-15",
    updatedAt: "2023-11-15",
  },
  {
    id: "2",
    title: "Code Explainer",
    content:
      "Explain the following code in simple terms, highlighting its purpose, how it works, and any potential improvements:\n\n```\n[paste code here]\n```",
    description: "Get clear explanations of code snippets in plain language.",
    category: "Technical",
    tags: ["programming", "code", "learning"],
    models: ["GPT-4", "Claude 3 Opus", "Llama 3"],
    createdAt: "2023-12-03",
    updatedAt: "2024-01-12",
  },
  {
    id: "3",
    title: "Email Response Template",
    content:
      "Draft a professional email response to the following message. The tone should be [friendly/formal/apologetic]. Include [specific points to address]:\n\n[Original email content]",
    description: "Create professional email responses for various situations.",
    category: "Business",
    tags: ["email", "communication", "professional"],
    models: ["GPT-4", "GPT-3.5 Turbo", "Claude 3 Sonnet"],
    createdAt: "2024-01-20",
    updatedAt: "2024-01-20",
  },
  {
    id: "4",
    title: "Blog Post Outline",
    content:
      'Create a detailed outline for a blog post titled "[title]". The target audience is [describe audience]. The post should cover [main topics]. Include suggestions for an engaging introduction and conclusion.',
    description: "Generate structured outlines for blog posts on any topic.",
    category: "Creative Writing",
    tags: ["blogging", "content creation", "writing"],
    models: ["GPT-4", "Claude 3", "Mistral Large"],
    createdAt: "2024-02-05",
    updatedAt: "2024-02-15",
  },
  {
    id: "5",
    title: "Data Analysis Plan",
    content:
      "Create a step-by-step plan for analyzing [type of data] to answer the following research questions: [list questions]. Include recommended statistical methods, visualization techniques, and potential pitfalls to avoid.",
    description: "Develop comprehensive data analysis plans for research projects.",
    category: "Technical",
    tags: ["data science", "statistics", "research"],
    models: ["GPT-4", "Claude 3 Opus", "Llama 3"],
    createdAt: "2024-02-28",
    updatedAt: "2024-02-28",
  },
  {
    id: "6",
    title: "Learning Concept Explainer",
    content:
      "Explain the concept of [concept] in simple terms. Then, provide increasingly detailed explanations as if teaching it to: 1) a 10-year-old, 2) a high school student, 3) a college student, and 4) a graduate student in the field.",
    description: "Get layered explanations of complex concepts for different knowledge levels.",
    category: "Education",
    tags: ["learning", "explanation", "teaching"],
    models: ["GPT-4", "Claude 3", "Mistral Large"],
    createdAt: "2024-03-10",
    updatedAt: "2024-03-10",
  },
]

// In a real application, these functions would interact with a database
export const promptOperations = {
  getPrompt: (id: string) => {
    return promptData.find((prompt) => prompt.id === id)
  },

  getAllPrompts: () => {
    return [...promptData]
  },

  createPrompt: (promptData: Omit<Prompt, "id" | "createdAt" | "updatedAt">) => {
    const newPrompt = {
      ...promptData,
      id: String(Math.floor(Math.random() * 10000)),
      createdAt: new Date().toISOString().split("T")[0],
      updatedAt: new Date().toISOString().split("T")[0],
    }

    // In a real app, you would add this to the database
    console.log("Created new prompt:", newPrompt)
    return newPrompt
  },

  updatePrompt: (id: string, promptData: Partial<Omit<Prompt, "id" | "createdAt">>) => {
    const existingPrompt = promptData.find((prompt) => prompt.id === id)

    if (!existingPrompt) {
      throw new Error(`Prompt with ID ${id} not found`)
    }

    const updatedPrompt = {
      ...existingPrompt,
      ...promptData,
      updatedAt: new Date().toISOString().split("T")[0],
    }

    // In a real app, you would update this in the database
    console.log("Updated prompt:", updatedPrompt)
    return updatedPrompt
  },

  deletePrompt: (id: string) => {
    // In a real app, you would delete this from the database
    console.log(`Deleted prompt with ID: ${id}`)
    return true
  },
}

