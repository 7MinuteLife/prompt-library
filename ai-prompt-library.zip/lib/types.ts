export interface Prompt {
  id: string
  title: string
  content: string
  description: string
  category: string
  tags: string[]
  models: string[]
  createdAt: string
  updatedAt: string
}

export interface Category {
  id: string
  name: string
}

