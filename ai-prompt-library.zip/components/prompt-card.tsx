import Link from "next/link"
import { Copy, Star } from "lucide-react"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardFooter, CardHeader } from "@/components/ui/card"
import type { Prompt } from "@/lib/types"

interface PromptCardProps {
  prompt: Prompt
}

export default function PromptCard({ prompt }: PromptCardProps) {
  return (
    <Card className="flex h-full flex-col">
      <CardHeader className="flex flex-row items-start justify-between space-y-0 pb-2">
        <div className="space-y-1">
          <Link href={`/prompt/${prompt.id}`} className="font-semibold hover:underline">
            {prompt.title}
          </Link>
          <div>
            <Badge variant="outline">{prompt.category}</Badge>
          </div>
        </div>
        <Button variant="ghost" size="icon" className="h-8 w-8">
          <Star className="h-4 w-4" />
          <span className="sr-only">Favorite</span>
        </Button>
      </CardHeader>
      <CardContent className="flex-1">
        <p className="text-sm text-muted-foreground line-clamp-3">{prompt.description}</p>
      </CardContent>
      <CardFooter className="flex items-center justify-between border-t p-4">
        <div className="flex flex-wrap gap-1">
          {prompt.tags.slice(0, 2).map((tag) => (
            <Badge key={tag} variant="secondary" className="text-xs">
              {tag}
            </Badge>
          ))}
          {prompt.tags.length > 2 && (
            <Badge variant="secondary" className="text-xs">
              +{prompt.tags.length - 2}
            </Badge>
          )}
        </div>
        <Button variant="ghost" size="sm" className="h-8 gap-1">
          <Copy className="h-3.5 w-3.5" />
          <span className="sr-only sm:not-sr-only sm:inline">Copy</span>
        </Button>
      </CardFooter>
    </Card>
  )
}

