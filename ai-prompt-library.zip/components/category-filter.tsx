"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { categories } from "@/lib/data"

export default function CategoryFilter() {
  const [activeCategory, setActiveCategory] = useState<string>("all")

  return (
    <div className="flex flex-wrap gap-2">
      <Button
        variant={activeCategory === "all" ? "default" : "outline"}
        size="sm"
        onClick={() => setActiveCategory("all")}
      >
        All
      </Button>
      {categories.map((category) => (
        <Button
          key={category.id}
          variant={activeCategory === category.id ? "default" : "outline"}
          size="sm"
          onClick={() => setActiveCategory(category.id)}
        >
          {category.name}
        </Button>
      ))}
    </div>
  )
}

