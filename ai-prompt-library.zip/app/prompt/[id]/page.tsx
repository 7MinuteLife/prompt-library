import Link from "next/link"
import { ArrowLeft, Copy, Edit, Star, Trash2 } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Card, CardContent } from "@/components/ui/card"
import { promptData } from "@/lib/data"
import PromptActions from "@/components/prompt-actions"

interface PromptPageProps {
  params: {
    id: string
  }
}

export default function PromptPage({ params }: PromptPageProps) {
  // In a real app, you would fetch this data from an API
  const prompt = promptData.find((p) => p.id === params.id) || promptData[0]

  return (
    <div className="container max-w-4xl py-10">
      <Button variant="ghost" size="sm" asChild className="mb-6">
        <Link href="/" className="flex items-center gap-1">
          <ArrowLeft className="h-4 w-4" />
          Back to Library
        </Link>
      </Button>

      <div className="mb-8 flex items-start justify-between">
        <div>
          <h1 className="text-3xl font-bold">{prompt.title}</h1>
          <div className="mt-2 flex items-center gap-2">
            <Badge variant="outline">{prompt.category}</Badge>
            <span className="text-sm text-muted-foreground">Created on {prompt.createdAt}</span>
          </div>
        </div>
        <div className="flex gap-2">
          <Button variant="outline" size="icon">
            <Star className="h-4 w-4" />
            <span className="sr-only">Favorite</span>
          </Button>
          <Button variant="outline" size="icon" asChild>
            <Link href={`/prompt/${prompt.id}/edit`}>
              <Edit className="h-4 w-4" />
              <span className="sr-only">Edit</span>
            </Link>
          </Button>
          <Button variant="outline" size="icon">
            <Trash2 className="h-4 w-4" />
            <span className="sr-only">Delete</span>
          </Button>
        </div>
      </div>

      <Card className="mb-8">
        <CardContent className="p-6">
          <div className="mb-4 flex justify-between">
            <h2 className="text-lg font-semibold">Prompt Content</h2>
            <Button variant="ghost" size="sm" className="flex items-center gap-1">
              <Copy className="h-4 w-4" />
              Copy
            </Button>
          </div>
          <div className="whitespace-pre-wrap rounded-md bg-muted p-4 font-mono text-sm">{prompt.content}</div>
        </CardContent>
      </Card>

      <div className="mb-8">
        <h2 className="mb-4 text-lg font-semibold">Description</h2>
        <p className="text-muted-foreground">{prompt.description}</p>
      </div>

      <div className="mb-8">
        <h2 className="mb-4 text-lg font-semibold">Tags</h2>
        <div className="flex flex-wrap gap-2">
          {prompt.tags.map((tag) => (
            <Badge key={tag} variant="secondary">
              {tag}
            </Badge>
          ))}
        </div>
      </div>

      <div>
        <h2 className="mb-4 text-lg font-semibold">Compatible Models</h2>
        <div className="flex flex-wrap gap-2">
          {prompt.models.map((model) => (
            <Badge key={model} variant="outline">
              {model}
            </Badge>
          ))}
        </div>
      </div>
      <div className="mt-12 border-t pt-6">
        <h2 className="mb-4 text-lg font-semibold">Danger Zone</h2>
        <PromptActions promptId={params.id} />
      </div>
    </div>
  )
}

