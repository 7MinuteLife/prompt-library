"use client"

import type React from "react"

import { useState, useEffect } from "react"
import Link from "next/link"
import { ArrowLeft } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Label } from "@/components/ui/label"
import { Badge } from "@/components/ui/badge"
import { categories, promptData } from "@/lib/data"
import { useRouter } from "next/navigation"

interface EditPromptPageProps {
  params: {
    id: string
  }
}

export default function EditPromptPage({ params }: EditPromptPageProps) {
  const router = useRouter()
  const promptId = params.id

  // In a real app, you would fetch this data from an API
  const promptToEdit = promptData.find((p) => p.id === promptId)

  const [title, setTitle] = useState("")
  const [category, setCategory] = useState("")
  const [tags, setTags] = useState<string[]>([])
  const [tagInput, setTagInput] = useState("")
  const [content, setContent] = useState("")
  const [description, setDescription] = useState("")
  const [model, setModel] = useState("")

  useEffect(() => {
    if (promptToEdit) {
      setTitle(promptToEdit.title)
      setCategory(promptToEdit.category.toLowerCase())
      setTags(promptToEdit.tags)
      setContent(promptToEdit.content)
      setDescription(promptToEdit.description)
      setModel(promptToEdit.models[0] || "")
    }
  }, [promptToEdit])

  const handleAddTag = (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === "Enter" && tagInput.trim() !== "") {
      e.preventDefault()
      if (!tags.includes(tagInput.trim())) {
        setTags([...tags, tagInput.trim()])
      }
      setTagInput("")
    }
  }

  const handleRemoveTag = (tagToRemove: string) => {
    setTags(tags.filter((tag) => tag !== tagToRemove))
  }

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()

    // In a real app, you would send this data to your API
    const updatedPrompt = {
      id: promptId,
      title,
      category: category.charAt(0).toUpperCase() + category.slice(1),
      tags,
      content,
      description,
      models: [model],
      createdAt: promptToEdit?.createdAt || new Date().toISOString().split("T")[0],
      updatedAt: new Date().toISOString().split("T")[0],
    }

    console.log("Updated prompt:", updatedPrompt)

    // Redirect back to the prompt detail page
    router.push(`/prompt/${promptId}`)
  }

  if (!promptToEdit) {
    return (
      <div className="container py-10">
        <p>Prompt not found</p>
        <Button asChild className="mt-4">
          <Link href="/">Back to Library</Link>
        </Button>
      </div>
    )
  }

  return (
    <div className="container max-w-4xl py-10">
      <div className="mb-8">
        <Button variant="ghost" size="sm" asChild className="mb-2">
          <Link href={`/prompt/${promptId}`} className="flex items-center gap-1">
            <ArrowLeft className="h-4 w-4" />
            Back to Prompt
          </Link>
        </Button>
        <h1 className="text-3xl font-bold">Edit Prompt</h1>
        <p className="text-muted-foreground">Update your prompt details</p>
      </div>

      <form className="space-y-8" onSubmit={handleSubmit}>
        <div className="space-y-4">
          <div className="grid gap-2">
            <Label htmlFor="title">Prompt Title</Label>
            <Input
              id="title"
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              placeholder="Enter a descriptive title"
              className="w-full"
              required
            />
          </div>

          <div className="grid gap-2">
            <Label htmlFor="category">Category</Label>
            <Select value={category} onValueChange={setCategory} required>
              <SelectTrigger>
                <SelectValue placeholder="Select a category" />
              </SelectTrigger>
              <SelectContent>
                {categories.map((cat) => (
                  <SelectItem key={cat.id} value={cat.id}>
                    {cat.name}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          <div className="grid gap-2">
            <Label htmlFor="tags">Tags</Label>
            <div className="flex flex-wrap gap-2 mb-2">
              {tags.map((tag) => (
                <Badge key={tag} variant="secondary" className="gap-1">
                  {tag}
                  <button
                    type="button"
                    onClick={() => handleRemoveTag(tag)}
                    className="ml-1 rounded-full text-muted-foreground hover:text-foreground"
                  >
                    ×
                  </button>
                </Badge>
              ))}
            </div>
            <Input
              id="tags"
              placeholder="Add tags and press Enter"
              value={tagInput}
              onChange={(e) => setTagInput(e.target.value)}
              onKeyDown={handleAddTag}
            />
          </div>

          <div className="grid gap-2">
            <Label htmlFor="prompt">Prompt Content</Label>
            <Textarea
              id="prompt"
              value={content}
              onChange={(e) => setContent(e.target.value)}
              placeholder="Write your prompt here..."
              className="min-h-[200px]"
              required
            />
          </div>

          <div className="grid gap-2">
            <Label htmlFor="description">Description (Optional)</Label>
            <Textarea
              id="description"
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              placeholder="Add a description or notes about this prompt"
              className="min-h-[100px]"
            />
          </div>

          <div className="grid gap-2">
            <Label htmlFor="model">Primary Compatible Model</Label>
            <Select value={model} onValueChange={setModel}>
              <SelectTrigger>
                <SelectValue placeholder="Select primary model" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="gpt-4o">GPT-4o</SelectItem>
                <SelectItem value="gpt-4">GPT-4</SelectItem>
                <SelectItem value="gpt-3.5-turbo">GPT-3.5 Turbo</SelectItem>
                <SelectItem value="claude-3-opus">Claude 3 Opus</SelectItem>
                <SelectItem value="claude-3-sonnet">Claude 3 Sonnet</SelectItem>
                <SelectItem value="llama-3">Llama 3</SelectItem>
                <SelectItem value="mistral-large">Mistral Large</SelectItem>
                <SelectItem value="any">Any Model</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </div>

        <div className="flex justify-end gap-4">
          <Button variant="outline" type="button" asChild>
            <Link href={`/prompt/${promptId}`}>Cancel</Link>
          </Button>
          <Button type="submit">Save Changes</Button>
        </div>
      </form>
    </div>
  )
}

